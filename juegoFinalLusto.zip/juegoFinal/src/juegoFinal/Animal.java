package juegoFinal;

public abstract class Animal {
	protected float precio;
	protected int contadorComida;
	protected boolean alimentado;
	
	
	public abstract int getContadorComida();
	public abstract float getPrecio();
	public abstract boolean estaAlimentado();
	public abstract void comer();
	
}
