package juegoFinal;

public class Choclo extends Cultivo implements Vendible{
	public Choclo() {
		super.precio = 105.99f;
		super.contadorAgua = 0;
		super.regado = false;
	}
	@Override
	public float getContadorAgua() {
		return super.contadorAgua;
	}

	@Override
	public float getPrecio() {
		return super.precio;
	}

	@Override
	protected boolean estaRegado() {
		if(super.contadorAgua>=1.00f) {
			super.regado= true;
		}else {
			super.regado = false;
		}
		return super.regado;
	}

	@Override
	protected void absorberAgua() {
		if(this.estaRegado()==false) {
			super.contadorAgua=super.contadorAgua + 0.25f;
		}
		
	}

	@Override
	public boolean esVendible() {
		return this.estaRegado();
	}

}
