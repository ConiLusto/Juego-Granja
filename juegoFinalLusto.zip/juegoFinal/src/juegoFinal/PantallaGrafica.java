package juegoFinal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class PantallaGrafica extends JFrame{
	public PantallaGrafica(Granja granja) {
		JLabel titulo = new JLabel("Granja La vaca Lola");
		titulo.setHorizontalAlignment(SwingConstants.CENTER);
		titulo.setFont(new Font("Cambria",2,30));
		titulo.setForeground(Color.MAGENTA);
		this.add(titulo,BorderLayout.NORTH);
		
		JPanel grilla = new JPanel();
		grilla.setLayout(new GridLayout(2,2));
		Panel panelVaca = new Panel("vaquita.png","Alimentar");
		Panel panelCerdo = new Panel("piggy.png","Alimentar");
		Panel panelTrigo = new Panel("trigo.png","Regar");
		Panel panelChoclo = new Panel("corn.png","Regar");
		grilla.add(panelVaca);
		grilla.add(panelCerdo);
		grilla.add(panelTrigo);
		grilla.add(panelChoclo);
		this.add(grilla,BorderLayout.CENTER);
		JLabel etiqueta = new JLabel("Sea bienvenido a su granja gr�fica");
		JLabel lblBilletera = new JLabel("Billetera: "+Billetera.getInstance().getDineroTotal());
		
		etiqueta.setFont(new Font("Cambria",2,20));
		lblBilletera.setFont(new Font("Cambria",0,20));
		
		JPanel panelFinal = new JPanel();
	
		panelFinal.setLayout(new GridLayout(2,1));
		panelFinal.add(etiqueta);
		panelFinal.add(lblBilletera);
		
		
	
	
		this.add(panelFinal,BorderLayout.SOUTH);
		
		panelVaca.getBtn1().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.estanTodasLasVacasAlimentadas()==false) {
					granja.alimentarTodasLasVacas();
					etiqueta.setText("+1 alimento para todas las vacas. Se llenan con 3");
					
				} else {
					etiqueta.setText("Las vacas ya est�n alimentadas: aptas para la venta");	
				}
			}
		});
		
		panelVaca.getBtn2().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.venderVaca()) {
					etiqueta.setText("Vaca vendida con �xito, quedan "+granja.getVacas().size());
					lblBilletera.setText("Billetera: "+Billetera.getInstance().getDineroTotal());
				}else {
					etiqueta.setText("No se puede vender vaca");
				}
				
				//granja.venderAnimal(granja.getVacas().get(0))
			}
			
		});
		
		panelCerdo.getBtn1().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.estanTodosLosCerdosAlimentados()==false) {
					granja.alimentarTodosLosCerdos();
					etiqueta.setText("+1 alimento para todos los cerdos. Se llenan con 5");	
				} else {
					etiqueta.setText("Los cerdos ya est�n alimentados: aptos para la venta");	
				}
			}
				
			
		});
		panelCerdo.getBtn2().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.venderCerdo()) {
					etiqueta.setText("Cerdo vendido con �xito, quedan "+granja.getCerdos().size());
					lblBilletera.setText("Billetera: "+Billetera.getInstance().getDineroTotal());
				}else {
					etiqueta.setText("No se puede vender cerdo");
				}
				
			}
			
		});
		
		panelTrigo.getBtn1().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.estanTodosLosTrigosRegados()==false) {
					granja.regarTodoElTrigo();
					etiqueta.setText("+0.25 ml de agua por trigo. Se llenan con 0.75 ml");	
				} else {
					etiqueta.setText("El trigo ya est� regado lo suficiente: apto para vender");	
				}
			}
				
			
		});
		panelTrigo.getBtn2().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.venderTrigo()) {
					etiqueta.setText("Trigo vendido con �xito, quedan "+granja.getTrigos().size());
					lblBilletera.setText("Billetera: "+Billetera.getInstance().getDineroTotal());
				}else {
					etiqueta.setText("No se puede vender trigo");
				}
				
			}
			
		});

		panelChoclo.getBtn1().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.estanTodosLosChoclosRegados()==false) {
					granja.regarTodoElChoclo();
					etiqueta.setText("+0.25 ml de agua por choclo. Se llenan con 1 L");	
				} else {
					etiqueta.setText("El choclo ya est� regado lo suficiente: apto para vender");	
				}
			}
				
			
		});
		panelChoclo.getBtn2().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(granja.venderChoclo()) {
					etiqueta.setText("Choclo vendido con �xito, quedan "+granja.getChoclos().size());
					lblBilletera.setText("Billetera: "+Billetera.getInstance().getDineroTotal());
				}else {
					etiqueta.setText("No se puede vender choclo");
				}
				
			}
			
		});
		
		
		/*
		JButton btn1 = new JButton("Alimentar");
		JButton btn2 = new JButton("Vender");
		JButton btn3 = new JButton("Salir");
		JLabel label = new JLabel();
		JPanel panelBotones = new JPanel();
		JLabel imagen = new JLabel(new ImageIcon("vaquita.png"));
		this.add(imagen,BorderLayout.NORTH);
		
		this.add(label,BorderLayout.CENTER);
		panelBotones.setLayout(new GridLayout(1,3));
		panelBotones.add(btn1);
		panelBotones.add(btn2);
		panelBotones.add(btn3);
		this.add(panelBotones,BorderLayout.SOUTH);
		
		btn1.addActionListener(new ActionListener() {
			int cont=0;
			public void actionPerformed(ActionEvent e) { 
				cont = cont+1;
				if(cont<=3) {
					for(Vaca v : granja.getVacas()) {
					granja.alimentar(v);
					}
					label.setText("+1 alimento");	
				} else if(cont>3) {
					cont--;
					label.setText("Las vacas ya est�n alimentadas, han sido alimentadas "+cont+" vez/veces");
					//label.setText("todas las vacas han sido alimentadas "+cont+" vez/veces");		
				}
			}
			
		});
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
					label.setText(granja.venderAnimal(granja.getVacas().get(0)));
			}
		});
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				label.setText("El juego ha finalizado con �xito");
			}
		});
		
		
		
		
		*/
		
	}
	

}
