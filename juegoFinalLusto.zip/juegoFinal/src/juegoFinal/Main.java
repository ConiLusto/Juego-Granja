package juegoFinal;

import java.util.Scanner;

import javax.swing.JFrame;



public class Main {

	public static void main(String[] args) {
		Granja granja = new Granja();
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("1-jugar por interfaz gr�fica");
		System.out.println("2-jugar por consola");
		String decision = teclado.next();
		if(decision.equals("1")) {
			PantallaGrafica p1 = new PantallaGrafica(granja); 
			p1.setSize(500,600);
			p1.setLocationRelativeTo(null);
			p1.setVisible(true);
			p1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			p1.setTitle("Granja gr�fica");
		
		}
		if(decision.equals("2")) {
			GranjaConsola consola = new GranjaConsola(granja);
		}
	}
}
			



