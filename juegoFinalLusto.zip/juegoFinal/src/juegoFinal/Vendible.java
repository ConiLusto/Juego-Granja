package juegoFinal;

public interface Vendible {
	public boolean esVendible();

}
