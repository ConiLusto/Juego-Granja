package juegoFinal;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
//import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Panel extends JPanel{
	private JButton btn1,btn2;
	private JLabel imagen;
	private JPanel panelBotones;
	
	public Panel(String nombreImagen,String accion) {
		//this.setLayout(new GridLayout(2,1));
		imagen = new JLabel(new ImageIcon(nombreImagen));
		this.add(imagen,BorderLayout.CENTER);
		//this.add(imagen);
		btn1 = new JButton(accion);
		btn2 = new JButton("Vender");
		panelBotones = new JPanel();
		panelBotones.add(btn1);
		panelBotones.add(btn2);
		this.add(panelBotones,BorderLayout.SOUTH);
		//this.add(panelBotones);
		
	}

	public JButton getBtn1() {
		return btn1;
	}

	public void setBtn1(JButton btn1) {
		this.btn1 = btn1;
	}

	public JButton getBtn2() {
		return btn2;
	}

	public void setBtn2(JButton btn2) {
		this.btn2 = btn2;
	}

	public JLabel getImagen() {
		return imagen;
	}

	public void setImagen(JLabel imagen) {
		this.imagen = imagen;
	}

	public JPanel getPanelBotones() {
		return panelBotones;
	}

	public void setPanelBotones(JPanel panelBotones) {
		this.panelBotones = panelBotones;
	}
	
	
}
