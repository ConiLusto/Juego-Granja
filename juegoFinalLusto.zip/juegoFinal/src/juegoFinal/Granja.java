package juegoFinal;

import java.util.ArrayList;

public class Granja {
	private ArrayList<Vaca> vacas = new ArrayList<Vaca>();
	private ArrayList<Cerdo> cerdos = new ArrayList<Cerdo>();
	private ArrayList<Trigo> trigos = new ArrayList<Trigo>();
	private ArrayList<Choclo> choclos = new ArrayList<Choclo>();
	
	
	public Granja() {
		this.vacas.add(new Vaca());
		this.vacas.add(new Vaca());
		this.vacas.add(new Vaca());
		this.vacas.add(new Vaca());
		this.vacas.add(new Vaca());
		
		this.cerdos.add(new Cerdo());
		this.cerdos.add(new Cerdo());
		this.cerdos.add(new Cerdo());
		this.cerdos.add(new Cerdo());
		this.cerdos.add(new Cerdo());
		
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		this.trigos.add(new Trigo());
		

		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		this.choclos.add(new Choclo());
		
		
	}
//Getters
	public ArrayList<Vaca> getVacas() {
		return vacas;
	}

	public ArrayList<Cerdo> getCerdos() {
		return cerdos;
	}
	
	public ArrayList<Trigo> getTrigos() {
		return trigos;
	}
	public ArrayList<Choclo> getChoclos() {
		return choclos;
	}
//metodos vacas
	public void alimentarVaca(Vaca v) {
		v.comer();
	}
	
	public void alimentarTodasLasVacas() {
		for(Vaca v : this.getVacas()) {
			this.alimentarVaca(v);
			}
	}
	
	public boolean venderVaca() { 
		boolean resultado = false;
			if(this.getVacas().size()!=0 && this.getVacas().get(0).esVendible()) {
				Billetera.getInstance().calcularIngresos(this.getVacas().get(0).getPrecio());
				this.getVacas().remove(0);
				resultado = true;
			}
	
		return resultado;
	}
		
	
	
	public boolean estanTodasLasVacasAlimentadas() {
		
		/*boolean vacasAlimentadas = true;
		 * int i=0;
		while(vacasAlimentadas==true) {
			Vaca v = this.getVacas().get(i);
			vacasAlimentadas = v.estaAlimentada();
			i++;
		}	
			return vacasAlimentadas;
		 * */
		boolean vacasAlimentadas = true;
		for(Vaca v : this.getVacas()) {
			vacasAlimentadas = v.estaAlimentado();
			}
		
		return vacasAlimentadas;
	}
	
	
	//metodos cerdos
	
	public void alimentarCerdo(Cerdo c) {
		c.comer();
	}
	public void alimentarTodosLosCerdos() {
		for(Cerdo c : this.getCerdos()) {
			this.alimentarCerdo(c);
		}
	}
	public boolean estanTodosLosCerdosAlimentados() {
		boolean cerdosAlimentados = true;
		for(Cerdo c : this.getCerdos()) {
			cerdosAlimentados = c.estaAlimentado();
		}
		return cerdosAlimentados;
	}
	public boolean venderCerdo() { 
		boolean resultado = false;
			if(this.getCerdos().size()!=0 && this.getCerdos().get(0).esVendible()) {
				Billetera.getInstance().calcularIngresos(this.getCerdos().get(0).getPrecio());
				this.getCerdos().remove(0);
				resultado = true;
			}
	
		return resultado;
	}
	
	public void regarTrigo(Trigo t) {
		t.absorberAgua();
	}
	public void regarTodoElTrigo() {
		for(Trigo t : this.getTrigos()) {
			this.regarTrigo(t);
		}
	}
	public boolean estanTodosLosTrigosRegados() {
		boolean trigosRegados = true;
		for(Trigo t : this.getTrigos()) {
			trigosRegados = t.estaRegado();
		}
		return trigosRegados;
	}
	public boolean venderTrigo() { 
		boolean resultado = false;
			if(this.getTrigos().size()!=0 && this.getTrigos().get(0).esVendible()) {
				Billetera.getInstance().calcularIngresos(this.getTrigos().get(0).getPrecio());
				this.getTrigos().remove(0);
				resultado = true;
			}
	
		return resultado;
	}
	
	public void regarChoclo(Choclo ch) {
		ch.absorberAgua();
	}
	public void regarTodoElChoclo() {
		for(Choclo ch : this.getChoclos()) {
			this.regarChoclo(ch);
		}
	}
	public boolean estanTodosLosChoclosRegados() {
		boolean choclosRegados = true;
		for(Choclo ch : this.getChoclos()) {
			choclosRegados = ch.estaRegado();
		}
		return choclosRegados;
	}
	public boolean venderChoclo() { 
		boolean resultado = false;
			if(this.getChoclos().size()!=0 && this.getChoclos().get(0).esVendible()) {
				Billetera.getInstance().calcularIngresos(this.getChoclos().get(0).getPrecio());
				this.getChoclos().remove(0);
				resultado = true;
			}
	
		return resultado;
	}


	
	
}
