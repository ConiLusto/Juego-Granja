package juegoFinal;

public abstract class Cultivo {
	protected float precio;
	protected float contadorAgua;
	protected boolean regado;
	
	public abstract float getContadorAgua();
	public abstract float getPrecio();
	protected abstract boolean estaRegado();
	protected abstract void absorberAgua();
}
