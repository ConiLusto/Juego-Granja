package juegoFinal;

public class Cerdo extends Animal implements Vendible{
	public Cerdo() {
		super.precio = 250;
		super.contadorComida = 0;
		super.alimentado = false;
		
	}

	@Override
	public int getContadorComida() {
		return super.contadorComida;
	}

	@Override
	public float getPrecio() {
		return super.precio;
	}

	@Override
	public boolean estaAlimentado() {
		if(super.contadorComida>=5) {
			super.alimentado = true;
		}else {
			super.alimentado = false;
		}
		return super.alimentado;
	}

	@Override
	public void comer() {
		if(this.estaAlimentado()==false) {
			super.contadorComida++;
		}
		
	}

	@Override
	public boolean esVendible() {
		// TODO Auto-generated method stub
		return this.estaAlimentado();
	}

	
	
}
