package juegoFinal;



public class Billetera {
	private static Billetera instance;
	private float dineroTotal;
	
	private Billetera() {
		this.dineroTotal = 100;
	}
	
	public static Billetera getInstance() {
		if(instance==null) {
			instance = new Billetera();
		}
		return instance;
		
	}
	public void calcularIngresos(float ingreso) {
		this.dineroTotal=this.dineroTotal+ingreso;
	}

	public float getDineroTotal() {
		return this.dineroTotal;
	}
	
}
