package juegoFinal;

public class Vaca extends Animal implements Vendible {
	
	public Vaca() {
		super.precio = 500;
		super.contadorComida = 0;
		super.alimentado = false;
	}
	
	
	
	
	public int getContadorComida() {
			return super.contadorComida;
	}

	public float getPrecio() {
		return super.precio;
	}


	//si el contador es igual a 3, no dejo alimentar mas. devuelvo error
	public void comer() {
			if(this.estaAlimentado()==false) {
				super.contadorComida++;
			}
	
	}
	
	public boolean estaAlimentado() {
		if(super.contadorComida>=3) {
			super.alimentado = true;
		}else {
			super.alimentado = false;
		}
		return super.alimentado;
	}

	@Override
	public boolean esVendible() {
		return this.estaAlimentado();
	}
}