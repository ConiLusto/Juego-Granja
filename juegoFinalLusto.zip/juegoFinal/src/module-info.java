module juegoFinal {
	requires java.desktop;
}